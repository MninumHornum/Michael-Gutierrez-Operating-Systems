HOW TO USE

1. program will ask user to input admin first, then password next

2.user will then be prompted again to input same admin and password to login

3. once successfully logged in, user will see loading bar and successful access to Michael OS!